package memory.card.game

import memory.card.game.view.{GameController, HomePageController, LeaderboardController}
import scalafx.application.JFXApp
import scalafx.application.JFXApp.PrimaryStage
import scalafx.scene.Scene
import scalafx.Includes._
import scalafxml.core.{FXMLLoader, NoDependencyResolver}
import javafx.{scene => jfxs}
import scalafx.scene.image.Image
import util.Database

object MyApp extends JFXApp {

  Database.setup()

  private var _primaryStage: Option[PrimaryStage] = None

  def primaryStage: Option[PrimaryStage] = _primaryStage

  val rootResource = getClass.getResource("view/RootLayout.fxml")
  val rootLoader = new FXMLLoader(rootResource, NoDependencyResolver)
  rootLoader.load()
  val rootLayout = rootLoader.getRoot[jfxs.layout.BorderPane]

  stage = new PrimaryStage {
    title = "Memory Card Game"
    icons += new Image(getClass.getResourceAsStream("/images/card header.png"))
    _primaryStage = Some(this)
    println(s"Primary stage is initialized: ${_primaryStage.isDefined}")
    scene = new Scene {
      root = rootLayout
    }
  }

  // method to display homepage and controller
  def showHomePage(): Unit = {
    val resource = getClass.getResource("view/HomePage.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    val homePage = loader.load[jfxs.layout.AnchorPane]
    val controller = loader.getController[HomePageController#Controller]
    controller.initialize()  // Initialize with dynamic rows and cols

    rootLayout.setCenter(homePage)
  }

  // show game page based on different difficulty level
  def showGamePage(difficulty: String, username: String): Unit = {
    val (fxmlFile, rows, cols) = difficulty match {
      case "Easy" => ("view/GameEasy.fxml", 4, 4)
      case "Intermediate" => ("view/GameIntermediate.fxml", 4, 6)
      case "Hard" => ("view/GameHard.fxml", 6, 6)
      case _ => throw new IllegalArgumentException("Invalid difficulty level")
    }

    val resource = getClass.getResource(fxmlFile)
    val loader = new FXMLLoader(resource, NoDependencyResolver)

    try {
      val gamePage = loader.load[jfxs.layout.AnchorPane]

      // Access and configure the controller
      val controller1 = loader.getController[GameController#Controller]
      controller1.initialize(rows, cols, difficulty, username)  // Pass username to initialize

      rootLayout.setCenter(gamePage)
    } catch {
      case e: Exception =>
        println(s"Failed to load FXML file: $fxmlFile")
        e.printStackTrace()
    }
  }

  // display leaderboard page
  def showLeaderboardPage(): Unit = {
    val resource = getClass.getResource("view/Leaderboard.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    val leaderboardPage = loader.load[jfxs.layout.AnchorPane]
    rootLayout.setCenter(leaderboardPage)

    val controller2 = loader.getController[LeaderboardController#Controller]
    if (controller2 != null) {
      println("Controller successfully loaded")
      controller2.initialize()  // Call filterAllLevels to show all records by default
      println("Initializing LeaderboardController")
    } else {
      println("Controller is null")
    }
  }

  // Initialize with Home Page
  showHomePage()
}