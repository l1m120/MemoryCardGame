package memory.card.game.model

import memory.card.game.util.Database
import scalafx.beans.property.{IntegerProperty, ObjectProperty, StringProperty}

import java.time.{Duration, LocalDate}

// Represents a player in the memory card game with their game details.
class Player(
              usernames: String,
              difficultyLevels: String,
              playDate: LocalDate,
              timeTaken: Duration,
              scores: Int
            ) extends Database {
  // Properties for the player's details
  var name = new StringProperty(this, "name", usernames) // The player's username
  var level = new StringProperty(this, "level", difficultyLevels) // The difficulty level
  var date = new ObjectProperty[LocalDate](this, "date", playDate) // The date of play
  var time = new ObjectProperty[Duration](this, "time", timeTaken) // The time taken to complete the game
  var move = new IntegerProperty(this, "move", scores) // The number of moves made to complete the game

  // Sets the duration of time taken to complete the game.
  def setTimeTaken(duration: Duration): Unit = {
    time.value = duration
  }

  // Gets the duration of time taken to complete the game.
  def getTimeTaken: Duration = {
    time.value
  }

  // Sets the date when the game was played.
  def setPlayDate(playDate: LocalDate): Unit = {
    date.value = playDate
  }

  // Gets the date when the game was played.
  def getPlayDate: LocalDate = {
    date.value
  }
}



