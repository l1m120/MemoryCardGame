package memory.card.game.view

import scalafxml.core.macros.sfxml
import scalafx.event.ActionEvent
import scalafx.scene.image.ImageView

/**
 * Controller for the Rules & FAQ page of the memory card game.
 * Manages the navigation back to the home page and handles music control.
 */
@sfxml
class RulesFAQController (
                           private val musicButton: ImageView
                         ) {

  /**
   * Handles the action to go back to the previous page.
   */
  def handleGoBack(event: ActionEvent): Unit = {
    println(s"handleGoBack called with event: $event")
    try {
      // Get the current stage from the event source
      val stage = event.source.asInstanceOf[javafx.scene.Node].getScene.getWindow.asInstanceOf[javafx.stage.Stage]
      // Close the current stage
      stage.close()
    } catch {
      case e: Exception =>
        e.printStackTrace()
    }
  }
}
