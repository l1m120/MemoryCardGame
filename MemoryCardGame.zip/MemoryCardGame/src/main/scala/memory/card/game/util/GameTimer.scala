package memory.card.game.util

import scalafx.application.Platform
import scalafx.scene.control.Label

// class representing a game timer that updates a label with the elapsed time
class GameTimer(timerLabel: Label) {
  @volatile private var timerRunning: Boolean = false
  @volatile private var timerPaused: Boolean = false
  private var startTime: Long = _
  @volatile private var elapsedBeforePause: Long = 0

  //Starts the timer.
  //initializes the start time and begins updating the timer label every second.
  def startTimer(): Unit = {
    startTime = System.currentTimeMillis() - elapsedBeforePause
    timerRunning = true
    timerPaused = false

    new Thread(() => {
      while (timerRunning) {
        if (!timerPaused) {
          val currentTime = System.currentTimeMillis()
          Platform.runLater {
            val elapsed = currentTime - startTime
            val seconds = elapsed / 1000
            timerLabel.text = if (seconds == 1) s"$seconds second" else s"$seconds seconds"
          }
          Thread.sleep(1000)
        } else {
          Thread.sleep(100)
        }
      }
    }).start()
  }

  // pause the timer
  // stores the elapsed time before the pause
  def pauseTimer(): Unit = {
    timerPaused = true
    elapsedBeforePause = System.currentTimeMillis() - startTime
  }

  // resume the timer
  // resume the timer from where it was paused
  def resumeTimer(): Unit = {
    startTime = System.currentTimeMillis() - elapsedBeforePause
    timerPaused = false
  }

  // stops the timer
  def stopTimer(): Unit = {
    timerRunning = false
  }
}
