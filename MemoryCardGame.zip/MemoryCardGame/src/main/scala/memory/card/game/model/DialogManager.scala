package memory.card.game.model

import scalafx.Includes._
import scalafx.application.Platform
import scalafx.scene.control.{Alert, ButtonType, Dialog, ButtonBar}
import scalafx.scene.image.{Image, ImageView}
import scalafx.stage.Window

object DialogManager {

  // Load the image used for alerts
  private val alertImage = new Image(getClass.getResourceAsStream("/images/alert.png"))

  // display dialog when a game is completed
  def showCompletionDialog(owner: Window, elapsedTime: String, moveCount: Int, onCompleted: () => Unit): Unit = {
    Platform.runLater {
      val alert = new Alert(Alert.AlertType.Information) {
        initOwner(owner) // Set the owner of the dialog
        title = "Game Completed" // Set the title of the dialog
        headerText = "Congratulations!" // Set the header text of the dialog
        contentText = s"You have matched all pairs in $elapsedTime with $moveCount moves." // Set the content text of the dialog
        buttonTypes = Seq(ButtonType.OK) // Add an OK button to the dialog
        graphic = new ImageView(alertImage) // Set the graphic image for the dialog
      }

      // Show the dialog and execute the callback if the OK button is clicked
      alert.showAndWait().filter(_ == ButtonType.OK).foreach(_ => onCompleted())
    }
  }

  // shows dialog when the game is paused
  def showPauseDialog(owner: Window, onResume: () => Unit): Unit = {
    Platform.runLater {
      val dialog = new Dialog[ButtonType]() {
        initOwner(owner) // Set the owner of the dialog
        title = "Game Paused" // Set the title of the dialog
        graphic = new ImageView(alertImage) // Set the graphic image for the dialog
        headerText = "The game has been paused." // Set the header text of the dialog
        val resumeButtonType = new ButtonType("Resume") // Create a Resume button
        dialogPane().buttonTypes.addAll(resumeButtonType) // Add the Resume button to the dialog
      }

      // Show the dialog and execute the callback if the Resume button is clicked
      dialog.showAndWait().foreach {
        case resumeButtonType => onResume()
        case _ =>
      }
    }
  }


  // Displays a confirmation dialog when the user attempts to go back to the home page.
  def showGoBackConfirmationDialog(owner: Window, onExit: () => Unit, onContinue: () => Unit): Unit = {
    Platform.runLater {
      val exitButtonType = new ButtonType("Exit Anyway", ButtonBar.ButtonData.OKDone) // Create an Exit Anyway button
      val continueButtonType = new ButtonType("Continue Game", ButtonBar.ButtonData.No) // Create a Continue Game button

      val alert = new Alert(Alert.AlertType.Confirmation) {
        initOwner(owner) // Set the owner of the dialog
        title = "Confirmation" // Set the title of the dialog
        headerText = "Are you sure you want to go back to the home page?" // Set the header text of the dialog
        contentText = "You will lose your progress if you exit." // Set the content text of the dialog
        buttonTypes = Seq(exitButtonType, continueButtonType) // Add Exit Anyway and Continue Game buttons to the dialog
      }

      // Show the dialog and execute the appropriate callback based on the button clicked
      alert.showAndWait().foreach {
        case `exitButtonType` => onExit()
        case `continueButtonType` => onContinue()
        case _ =>
      }
    }
  }
}
