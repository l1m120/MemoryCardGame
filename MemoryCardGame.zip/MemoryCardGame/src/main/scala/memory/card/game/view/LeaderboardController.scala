package memory.card.game.view

import memory.card.game.MyApp
import memory.card.game.util.{Database, GameResult}
import scalafx.collections.ObservableBuffer
import scalafx.event.ActionEvent
import scalafx.scene.control.{Label, SplitMenuButton, TableColumn, TableView, MenuItem}
import scalafxml.core.macros.sfxml

/**
 * Controller for the leaderboard page of the memory card game.
 * Manages the display of game results, including filtering by difficulty level
 * and displaying the top three players.
 */
@sfxml
class LeaderboardController(
                             private val leaderboardTable: TableView[GameResult],
                             private val usernameColumn: TableColumn[GameResult, String],
                             private val difficultyColumn: TableColumn[GameResult, String],
                             private val datePlayedColumn: TableColumn[GameResult, java.sql.Timestamp],
                             private val timeTakenColumn: TableColumn[GameResult, String],
                             private val movesTakenColumn: TableColumn[GameResult, Int],
                             private val difficultyButton: SplitMenuButton,
                             private val firstPlaceLabel: Label,
                             private val secondPlaceLabel: Label,
                             private val thirdPlaceLabel: Label
                           ) {

  /**
   * Initializes the leaderboard controller.
   * By default, shows all game results.
   */
  def initialize(): Unit = {
    println("Initializing LeaderboardController")
    filterAllLevels() // Call filterAllLevels to show all records by default
  }

  /**
   * Refreshes the leaderboard table with game results.
   */
  def refreshLeaderboard(difficulty: Option[String] = None): Unit = {
    val results = difficulty match {
      case Some(level) if List("Easy", "Intermediate", "Hard").contains(level) =>
        ObservableBuffer(Database.getTopResultsByDifficulty(level): _*)
      case _ =>
        ObservableBuffer(Database.getAllResults(): _*)
    }
    leaderboardTable.items = results

    // Set cell value factories for the table columns
    usernameColumn.cellValueFactory = { _.value.usernameProperty }
    difficultyColumn.cellValueFactory = { _.value.difficultyProperty }
    datePlayedColumn.cellValueFactory = { _.value.datePlayedProperty }
    timeTakenColumn.cellValueFactory = { _.value.timeTakenProperty }
    movesTakenColumn.cellValueFactory = { _.value.movesTakenProperty }

    println(s"Loaded ${results.size} game results")

    // Update the labels with the top 3 players' names
    updateTopPlayers(difficulty)
  }

  /**
   * Updates the labels for the top 3 players.
   */
  def updateTopPlayers(difficulty: Option[String]): Unit = {
    difficulty match {
      case Some(level) if List("Easy", "Intermediate", "Hard").contains(level) =>
        val topPlayers = Database.getTopResultsByDifficulty(level, limit = 3)
        topPlayers match {
          case List(first, second, third) =>
            firstPlaceLabel.text = first.username
            secondPlaceLabel.text = second.username
            thirdPlaceLabel.text = third.username
          case List(first, second) =>
            firstPlaceLabel.text = first.username
            secondPlaceLabel.text = second.username
            thirdPlaceLabel.text = "No 3rd Place"
          case List(first) =>
            firstPlaceLabel.text = first.username
            secondPlaceLabel.text = "No 2nd Place"
            thirdPlaceLabel.text = "No 3rd Place"
          case _ =>
            firstPlaceLabel.text = "No 1st Place"
            secondPlaceLabel.text = "No 2nd Place"
            thirdPlaceLabel.text = "No 3rd Place"
        }
      case _ =>
        firstPlaceLabel.text = ""
        secondPlaceLabel.text = ""
        thirdPlaceLabel.text = ""
    }
  }

  /**
   * Handles the action to go back to the home page.
   */
  def handleGoBack(event: ActionEvent): Unit = {
    println(s"handleGoBack called with event: $event")
    try {
      // Close the current leaderboard stage
      val stage = event.source.asInstanceOf[javafx.scene.Node].getScene.getWindow.asInstanceOf[javafx.stage.Stage]
      stage.close()

      // Load and show the home page
      MyApp.showHomePage()
    } catch {
      case e: Exception =>
        e.printStackTrace()
    }
  }

  /**
   * Filters the leaderboard to show all levels.
   */
  def filterAllLevels(): Unit = {
    refreshLeaderboard(None)
  }

  /**
   * Filters the leaderboard to show only "Easy" level results.
   */
  def filterEasy(): Unit = {
    refreshLeaderboard(Some("Easy"))
  }

  /**
   * Filters the leaderboard to show only "Intermediate" level results.
   */
  def filterIntermediate(): Unit = {
    refreshLeaderboard(Some("Intermediate"))
  }

  /**
   * Filters the leaderboard to show only "Hard" level results.
   */
  def filterHard(): Unit = {
    refreshLeaderboard(Some("Hard"))
  }
}
