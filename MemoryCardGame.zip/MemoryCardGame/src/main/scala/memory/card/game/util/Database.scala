package memory.card.game.util

import scalikejdbc._
import java.sql.Timestamp

// A trait to set up and manage the database connection using ScalikeJDBC.
trait Database {
  // JDBC driver class name for the Apache Derby database
  val derbyDriverClassname = "org.apache.derby.jdbc.EmbeddedDriver"

  // Database URL for connection
  val dbURL = "jdbc:derby:myDB;create=true;"

  // Load the JDBC driver
  Class.forName(derbyDriverClassname)

  // Set up the connection pool with specific settings
  ConnectionPool.singleton(dbURL, "user", "pass", ConnectionPoolSettings(
    initialSize = 5, // Initial number of connections
    maxSize = 20, // Maximum number of connections
    connectionTimeoutMillis = 3000L, // Timeout for obtaining a connection
    validationQuery = "SELECT 1 FROM SYS.SYSSCHEMAS" // Query to validate connections
  ))

  // Implicit session to be used in database operations
  implicit val session: AutoSession.type = AutoSession
}

// Object to handle database setup and operations related to game results.

object Database extends Database {

  // Sets up the database by creating the game_results table if it doesn't exist.
  def setup(): Unit = {
    try {
      DB autoCommit { implicit session =>
        // Check if the table exists
        val tableExists = sql"""
          SELECT 1 FROM SYS.SYSTABLES WHERE TABLENAME = 'GAME_RESULTS'
        """.map(_.int(1)).single.apply().isDefined

        if (!tableExists) {
          sql"""
          CREATE TABLE game_results (
            id INT GENERATED ALWAYS AS IDENTITY,
            username VARCHAR(64),
            difficulty VARCHAR(64),
            date_played TIMESTAMP,
            time_taken VARCHAR(64),
            moves_taken INT,
            PRIMARY KEY (id)
          )
          """.execute.apply()
        }
      }
      println("Setting up Database")
    } catch {
      case e: Exception =>
        e.printStackTrace()
        throw new RuntimeException("Error setting up the database", e)
    }
  }

  // Formats the time from "MM:SS" format to total seconds
  def formatTime(time: String): Int = {
    val parts = time.split(":")
    if (parts.length == 2) {
      parts(0).toInt * 60 + parts(1).toInt // Convert time in "MM:SS" to total seconds
    } else {
      0
    }
  }

  // Retrieves all game results from the database and sorts them.
  def getGameResults(): List[GameResult] = {
    DB readOnly { implicit session =>
      val results = sql"""
      SELECT * FROM game_results
      """.map(rs => GameResult(
        rs.int("id"),
        rs.string("username"),
        rs.string("difficulty"),
        rs.timestamp("date_played"),
        rs.string("time_taken"),
        rs.int("moves_taken")
      )).list.apply()

      results.sortBy(result => (formatTime(result.timeTaken), result.movesTaken))
    }
  }

  // Saves a new game result to the database.
  def saveGameResult(username: String, difficulty: String, datePlayed: Timestamp, timeTaken: String, movesTaken: Int): Unit = {
    DB autoCommit { implicit session =>
      sql"""
      INSERT INTO game_results (username, difficulty, date_played, time_taken, moves_taken) VALUES
      ($username, $difficulty, $datePlayed, $timeTaken, $movesTaken)
      """.update.apply()
    }
  }

  // Retrieves the top results by difficulty level, limited to top 15 players.
  def getTopResultsByDifficulty(difficulty: String, limit: Int = 15): List[GameResult] = {
    DB readOnly { implicit session =>
      val results = sql"""
      SELECT * FROM game_results WHERE difficulty = $difficulty
      ORDER BY time_taken, moves_taken
      FETCH FIRST $limit ROWS ONLY
      """.map(rs => GameResult(
        rs.int("id"),
        rs.string("username"),
        rs.string("difficulty"),
        rs.timestamp("date_played"),
        rs.string("time_taken"),
        rs.int("moves_taken")
      )).list.apply()

      results
    }
  }

  // Retrieves all game results from the database, ordered by difficulty, time taken, and moves taken.
  def getAllResults(): List[GameResult] = {
    DB readOnly { implicit session =>
      val results = sql"""
      SELECT * FROM game_results
      ORDER BY difficulty, time_taken, moves_taken
      """.map(rs => GameResult(
        rs.int("id"),
        rs.string("username"),
        rs.string("difficulty"),
        rs.timestamp("date_played"),
        rs.string("time_taken"),
        rs.int("moves_taken")
      )).list.apply()

      results
    }
  }
}