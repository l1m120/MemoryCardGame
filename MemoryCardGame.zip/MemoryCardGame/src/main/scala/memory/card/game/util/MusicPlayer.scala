package memory.card.game.util

import scalafx.scene.image.{Image, ImageView}
import scalafx.scene.media.{Media, MediaPlayer}

// object that represents a music player for the game
object MusicPlayer {
  private var mediaPlayer: Option[MediaPlayer] = None
  private var isPlaying: Boolean = false // boolean to track if teh music is playing for synchronization purpose

  // initializes teh music player with the specified music file
  def initialize(musicFilePath: String): Unit = {
    if (mediaPlayer.isEmpty) {
      val musicResource = getClass.getResource(musicFilePath)
      if (musicResource != null) {
        val media = new Media(musicResource.toString)
        val player = new MediaPlayer(media)
        player.setOnEndOfMedia(() => player.seek(player.getStartTime)) // Loop the music
        mediaPlayer = Some(player)
      }
    }
  }

  // method to play music
  def playMusic(): Unit = {
    mediaPlayer.foreach(_.play())
    isPlaying = true
  }

  // method to pause music
  def pauseMusic(): Unit = {
    mediaPlayer.foreach(_.pause())
    isPlaying = false
  }

  // toggles the music playback state and updates the music button image
  def toggleMusic(musicButton: ImageView, onImagePath: String, offImagePath: String): Unit = {
    if (isPlaying) {
      pauseMusic()
      musicButton.setImage(new Image(getClass.getResourceAsStream(offImagePath)))
    } else {
      playMusic()
      musicButton.setImage(new Image(getClass.getResourceAsStream(onImagePath)))
    }
  }

  // check if the music is playing
  def isMusicPlaying: Boolean = isPlaying

  // updates teh music button image on the music playback state
  def updateMusicButton(musicButton: ImageView, onImagePath: String, offImagePath: String): Unit = {
    if (isPlaying) {
      musicButton.setImage(new Image(getClass.getResourceAsStream(onImagePath)))
    } else {
      musicButton.setImage(new Image(getClass.getResourceAsStream(offImagePath)))
    }
  }
}
