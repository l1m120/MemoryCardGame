package memory.card.game.view

import memory.card.game.MyApp
import memory.card.game.model.{Card, DialogManager, GameStatus}
import memory.card.game.util.{DateTimeManager, GameTimer, Database, MusicPlayer}
import scalafx.application.Platform
import scalafx.event.ActionEvent
import scalafx.scene.control.{Alert, Button, Label}
import scalafx.scene.image.ImageView
import scalafx.scene.layout.GridPane
import scalafxml.core.macros.sfxml

import java.sql.Timestamp
import java.util.Date
import scala.collection.mutable
import scala.util.{Failure, Random, Success, Try}
import javafx.scene.media.{Media, MediaPlayer}

/**
 * Controller for the main game logic and UI.
 * Manages the game grid, game status, timer, date-time display, and music.
 */
@sfxml
class GameController(
                      private val gameGrid: GridPane,
                      private val statusLabel: Label,
                      private val timerLabel: Label,
                      private val dateLabel: Label,
                      private val moveLabel: Label,
                      private val musicButton: ImageView
                    ) {
  // Game variables
  private var rows: Int = _
  private var cols: Int = _
  private var totalPairs: Int = _
  private var cards: Array[Array[Card]] = _
  private var cardValues: Array[Array[Int]] = _
  private var firstCard: Option[Card] = None
  private var secondCard: Option[Card] = None
  private val matchedPairs: mutable.Set[(Int, Int)] = mutable.Set()
  private val gameStatus = new GameStatus(statusLabel, moveLabel)
  private val dateTimeManager = new DateTimeManager(dateLabel)
  private val gameTimer = new GameTimer(timerLabel)
  private val onImagePath = "/images/on.png"
  private val offImagePath = "/images/off.png"
  private var matchSound: MediaPlayer = _
  private var winSound: MediaPlayer = _ // Sound to play when the player wins
  private var difficulty: String = _
  private var username: String = _

  // Initializes the game controller with the specified settings.
  def initialize(rows: Int, cols: Int, difficulty: String, username: String): Unit = {
    this.rows = rows
    this.cols = cols
    this.totalPairs = (rows * cols) / 2
    this.cards = Array.ofDim[Card](rows, cols)
    this.cardValues = Array.ofDim[Int](rows, cols)
    this.difficulty = difficulty
    this.username = username

    // Initialize the match and win sounds
    val matchSoundFile = getClass.getResource("/music/pop.mp3").toExternalForm
    matchSound = new MediaPlayer(new Media(matchSoundFile))

    val winSoundFile = getClass.getResource("/music/win.mp3").toExternalForm
    winSound = new MediaPlayer(new Media(winSoundFile))

    gameStatus.initialize(totalPairs)
    setupGame()
    gameTimer.startTimer()
    dateTimeManager.startUpdating()
    MusicPlayer.updateMusicButton(musicButton, onImagePath, offImagePath) // Update button image based on music state
  }

  // Toggles the music on or off when the music button is clicked.
  def handleMusicToggle(): Unit = {
    MusicPlayer.toggleMusic(musicButton, onImagePath, offImagePath)
  }

  // Sets up the game by initializing the card values and placing them on the grid.
  def setupGame(): Unit = {
    val values = generateCardValues()
    val shuffledValues = Random.shuffle(values).toArray

    for (i <- 0 until rows * cols) {
      val row = i / cols
      val col = i % cols
      cardValues(row)(col) = shuffledValues(i)
    }

    for (row <- 0 until rows; col <- 0 until cols) {
      val button = new Button()
      val card = new Card(row, col, cardValues(row)(col), button, difficulty)  // Pass difficulty to Card
      button.onAction = _ => handleCardFlip(card)
      gameGrid.add(button, col, row)
      cards(row)(col) = card
    }
  }

  // Generates a sequence of card values for the game.
  private def generateCardValues(): Seq[Int] = {
    val totalCards = rows * cols
    val numPairs = totalCards / 2
    (1 to numPairs).flatMap(x => Seq(x, x))
  }

  // Handles the card flip action when a card is clicked.
  private def handleCardFlip(card: Card): Unit = {
    // Prevent flipping a card that is already matched or flipping the same card twice in a row
    if (isMatched(card) || firstCard.contains(card)) {
      return
    }

    gameStatus.incrementMoveCount()

    if (firstCard.isEmpty) {
      firstCard = Some(card)
      card.reveal()
    } else if (secondCard.isEmpty) {
      secondCard = Some(card)
      card.reveal()
      checkForMatch()
    }
  }

  // Checks if a card is already matched.
  private def isMatched(card: Card): Boolean = {
    matchedPairs.exists { case (row, col) => row == card.row && col == card.col }
  }

  /**
   * Checks if the flipped cards form a matching pair.
   * If they match, they are marked as matched and the game status is updated.
   * If all pairs are matched, the game is won.
   * If they do not match, the cards are hidden again after a brief delay.
   */
  private def checkForMatch(): Unit = {
    (firstCard, secondCard) match {
      case (Some(card1), Some(card2)) =>
        if (card1.value == card2.value) {
          matchedPairs += ((card1.row, card1.col), (card2.row, card2.col))
          gameStatus.updateMatchedPairs(matchedPairs.size / 2)

          // Play the match sound
          matchSound.stop()
          matchSound.play()

          if (matchedPairs.size / 2 == totalPairs) {
            gameTimer.stopTimer()
            val timeTaken = timerLabel.text.value
            val movesTaken = gameStatus.getMoveCount
            val difficulty = this.difficulty
            val datePlayed = new Timestamp(new Date().getTime)

            // Play the win sound
            winSound.stop()
            winSound.play()

            Try {
              Database.saveGameResult(username, difficulty, datePlayed, timeTaken, movesTaken)
            } match {
              case Success(_) => println(s"Game result saved: $username, $difficulty, $datePlayed, $timeTaken, $movesTaken")
              case Failure(e) => e.printStackTrace()
            }

            Platform.runLater {
              MyApp.primaryStage.foreach { stage =>
                DialogManager.showCompletionDialog(
                  stage,
                  timerLabel.text.value,
                  gameStatus.getMoveCount,
                  () => MyApp.showHomePage()
                )
              }
            }
          }

          // Reset firstCard and secondCard
          firstCard = None
          secondCard = None
        } else {
          // Temporarily disable further card flipping
          val previousFirstCard = firstCard
          val previousSecondCard = secondCard
          firstCard = None
          secondCard = None

          new Thread(() => {
            Thread.sleep(500)
            Platform.runLater {
              previousFirstCard.foreach(_.hide())
              previousSecondCard.foreach(_.hide())
            }
          }).start()
        }
      case _ =>
    }
  }

  // Pauses the game and shows the pause dialog.
  def handlePause(): Unit = {
    gameTimer.pauseTimer()

    MyApp.primaryStage.foreach { stage =>
      DialogManager.showPauseDialog(
        stage,
        () => resumeGame()
      )
    }
  }

  /**
   * Handles the action to go back to the home page.
   * Pauses the game and shows a confirmation dialog.
   */
  def handleGoBack(event: ActionEvent): Unit = {
    gameTimer.pauseTimer()

    MyApp.primaryStage.foreach { stage =>
      DialogManager.showGoBackConfirmationDialog(
        stage,
        () => MyApp.showHomePage(),
        () => resumeGame()
      )
    }
  }

  /**
   * Resumes the game after it has been paused.
   */
  private def resumeGame(): Unit = {
    gameTimer.resumeTimer()
  }

  /**
   * Shows the leaderboard page.
   * Pauses the game before showing the leaderboard.
   */
  def handleLeaderboard(): Unit = {
    gameTimer.pauseTimer()
    MyApp.showLeaderboardPage()
  }
}
