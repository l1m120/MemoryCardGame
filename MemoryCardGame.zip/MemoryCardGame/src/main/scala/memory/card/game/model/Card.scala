package memory.card.game.model

import scalafx.scene.control.Button
import scalafx.scene.image.{Image, ImageView}


class Card(val row: Int, val col: Int, val value: Int, val button: Button, val difficulty: String) {

  // Determine the image paths based on the difficulty level
  private val (backImagePath, frontImagePath) = difficulty match {
    case "Easy" => ("/images/back (1).gif", s"/images/emoji 1 ($value).png")
    case "Intermediate" => ("/images/back (2).gif", s"/images/emoji 2 ($value).png")
    case "Hard" => ("/images/back (3).gif", s"/images/emoji 3 ($value).png")
    case _ => throw new IllegalArgumentException("Invalid difficulty level")
  }

  // Set the card to display its back image initially
  setBackImage()


  // Reveals the card by displaying its front image.

  def reveal(): Unit = {
    // Set the button's graphic to the front image of the card
    button.graphic = new ImageView(new Image(getClass.getResourceAsStream(frontImagePath)))
  }


  // Hides the card by displaying its back image.
  def hide(): Unit = {
    // Set the button's graphic to the back image of the card
    setBackImage()
  }

  // Sets the button's graphic to the card's back image.
  private def setBackImage(): Unit = {
    // Set the button's graphic to the back image of the card
    button.graphic = new ImageView(new Image(getClass.getResourceAsStream(backImagePath)))
  }
}
