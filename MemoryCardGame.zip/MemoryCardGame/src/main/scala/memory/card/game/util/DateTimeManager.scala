package memory.card.game.util

import scalafx.application.Platform
import scalafx.scene.control.Label

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Success

// Manages updating a given Label with the current date and time.
class DateTimeManager(dateLabel: Label) {

  // Formatter to convert LocalDateTime to a string in the specified pattern
  private val dateTimeFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

  // Starts the process of updating the dateLabel with the current date and time every second.
  def startUpdating(): Unit = {
    Future {
      while (true) {
        // Update the label text on the JavaFX Application Thread
        Platform.runLater {
          val now = LocalDateTime.now().format(dateTimeFormatter)
          dateLabel.text = now
        }
        Thread.sleep(1000) // Pause for 1 second before the next update
      }
    }.onComplete {
      case Success(_) => // Do nothing on success
      case _ => // Handle failure if needed
    }
  }
}
