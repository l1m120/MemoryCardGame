package memory.card.game.model

import scalafx.scene.control.Label

// Manages and displays the game's status, including move count and matched pairs.
class GameStatus(
                  private val statusLabel: Label,
                  private val moveLabel: Label
                ) {
  // Internal state variables
  private var moveCount: Int = 0 // Number of moves made by the player
  private var totalPairs: Int = 0 // Total number of card pairs in the game
  private var matchedPairs: Int = 0 // Number of card pairs matched by the player


  // Initializes the game status with the total number of pairs.
  def initialize(totalPairs: Int): Unit = {
    this.totalPairs = totalPairs
    this.moveCount = 0
    this.matchedPairs = 0
    updateMoveCount() // Update the move count label to show 0 moves
    updateMatchedPairs() // Update the matched pairs label to show 0/totalPairs
  }

  // Increments the move count by 1 and updates the move count display.
  def incrementMoveCount(): Unit = {
    moveCount += 1
    updateMoveCount() // Update the move count label with the new move count
  }

  // Updates the number of matched pairs and updates the display.
  def updateMatchedPairs(matchedPairs: Int): Unit = {
    this.matchedPairs = matchedPairs
    updateMatchedPairs() // Update the matched pairs label with the new value
  }


  // Gets the current move count.
  def getMoveCount: Int = moveCount

  // Updates the move count label with the current move count.
  private def updateMoveCount(): Unit = {
    moveLabel.text = s"$moveCount" // Set the move label text to the current move count
  }

  // Updates the matched pairs label with the current number of matched pairs.
  private def updateMatchedPairs(): Unit = {
    statusLabel.text = s"$matchedPairs/$totalPairs" // Set the status label text to the current matched pairs and total pairs
  }
}
