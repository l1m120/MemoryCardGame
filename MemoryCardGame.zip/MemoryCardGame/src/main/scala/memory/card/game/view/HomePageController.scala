package memory.card.game.view

import memory.card.game.MyApp
import memory.card.game.util.MusicPlayer
import scalafx.Includes._
import scalafx.collections.ObservableBuffer
import scalafx.event.ActionEvent
import scalafx.scene.{Parent, Scene}
import scalafx.scene.control.Alert.AlertType
import scalafx.scene.control.{Alert, ChoiceBox, SplitPane, TextField}
import scalafx.scene.image.{Image, ImageView}
import scalafx.scene.media.{Media, MediaPlayer}
import scalafx.animation.{ScaleTransition, Timeline}
import scalafx.stage.Stage
import scalafx.util.Duration
import scalafxml.core.macros.sfxml
import scalafxml.core.{FXMLLoader, NoDependencyResolver}

/**
 * Controller for the home page of the memory card game.
 * Manages the main UI elements, including username input, difficulty selection,
 * music control, and navigation to other pages like Rules/FAQ and Leaderboard.
 */
@sfxml
class HomePageController(
                          private val mainSplitPane: SplitPane,
                          private val usernameField: TextField,
                          private val difficultyChoiceBox: ChoiceBox[String],
                          private val musicButton: ImageView,
                          private val logoImageView: ImageView
                        ) {

  private var mediaPlayer: Option[MediaPlayer] = None
  private var isPlaying: Boolean = false
  private val onImagePath = "/images/on.png"
  private val offImagePath = "/images/off.png"
  private val fixedDividerPosition = 0.6
  private val startMusicPath = "/music/start.mp3"  // Path to the start.mp3 file

  /**
   * Initializes the home page controller.
   */
  def initialize(): Unit = {
    println("Initializing HomePageController")
    difficultyChoiceBox.items = ObservableBuffer("Easy", "Intermediate", "Hard")

    MusicPlayer.initialize("/music/bgm.mp3")
    MusicPlayer.playMusic()
    MusicPlayer.updateMusicButton(musicButton, onImagePath, offImagePath)

    // Set the initial divider position and add a listener to keep it fixed
    mainSplitPane.setDividerPositions(fixedDividerPosition)
    mainSplitPane.dividers.foreach { divider =>
      divider.positionProperty().addListener((_, _, _) => {
        divider.setPosition(fixedDividerPosition)
      })
    }

    // Load CSS
    val scene = mainSplitPane.getScene
    if (scene != null) {
      scene.getStylesheets.add(getClass.getResource("styles.css").toExternalForm)
    }

    setupAnimation()
  }

  /**
   * Sets up a scaling animation for the logo image view.
   */
  private def setupAnimation(): Unit = {
    val scaleTransition = new ScaleTransition {
      node = logoImageView
      fromX = 1.0
      toX = 1.2
      fromY = 1.0
      toY = 1.2
      cycleCount = Timeline.Indefinite
      autoReverse = true // Makes the animation reverse back to the original scale
      duration = Duration(2000) // Duration of the animation
    }
    scaleTransition.play()
  }

  /**
   * Handles the music toggle action.
   */
  def handleMusicToggle(): Unit = {
    MusicPlayer.toggleMusic(musicButton, onImagePath, offImagePath)
  }

  /**
   * Handles the action to show the Rules & FAQ page.
   */
  def handleRulesFAQ(event: ActionEvent): Unit = {
    try {
      val loader = new FXMLLoader(getClass.getResource("RulesFAQPage.fxml"), NoDependencyResolver)
      val root: javafx.scene.Parent = loader.load()
      val rootPane: Parent = new Parent(root) {}
      val stage = new Stage() {
        title = "Rules & FAQ"
        icons += new Image(getClass.getResourceAsStream("/images/card header.png"))
        scene = new Scene(rootPane)
      }
      stage.show()
    } catch {
      case e: Exception =>
        e.printStackTrace()
    }
  }

  /**
   * Handles the action to show the Leaderboard page.
   */
  def handleLeaderboard(event: ActionEvent): Unit = {
    try {
      val loader = new FXMLLoader(getClass.getResource("Leaderboard.fxml"), NoDependencyResolver)
      val root: javafx.scene.Parent = loader.load()
      val rootPane: Parent = new Parent(root) {}
      val stage = new Stage() {
        title = "Leaderboard"
        icons += new Image(getClass.getResourceAsStream("/images/card header.png"))
        scene = new Scene(rootPane)
      }
      stage.show()
    } catch {
      case e: Exception =>
        e.printStackTrace()
    }
  }

  /**
   * Handles the action to start the game.
   */
  def handleStartGame(event: ActionEvent): Unit = {
    val username = usernameField.text.value
    val difficulty = difficultyChoiceBox.value.value // Extract the actual value from the ObjectProperty

    if (username.isEmpty) {
      new Alert(AlertType.Warning) {
        initOwner(usernameField.scene().getWindow)
        title = "Input Error"
        headerText = "Missing Username"
        contentText = "Please enter your username to start the game."
      }.showAndWait()
    } else if (difficulty == null || difficulty.isEmpty) {
      new Alert(AlertType.Warning) {
        initOwner(usernameField.scene().getWindow)
        title = "Input Error"
        headerText = "Missing Difficulty Level"
        contentText = "Please select a difficulty level to start the game."
      }.showAndWait()
    } else {
      try {
        // Play the start.mp3 sound
        val startMusic = new Media(getClass.getResource(startMusicPath).toExternalForm)
        val startMusicPlayer = new MediaPlayer(startMusic)
        startMusicPlayer.play()

        // Proceed to the game page after the sound has started playing
        println(s"Primary stage is initialized: ${MyApp.primaryStage.isDefined}")
        println(s"Difficulty level: $difficulty")

        MyApp.primaryStage match {
          case Some(stage) =>
            println("Switching to game page...")
            MyApp.showGamePage(difficulty, username)  // Pass the username along with difficulty

          case None =>
            throw new IllegalStateException("Primary stage is not initialized.")
        }
      } catch {
        case e: Exception =>
          println(s"Exception: ${e.getMessage}")
          e.printStackTrace()
      }
    }
  }
}
