package memory.card.game.util

import java.sql.Timestamp
import scalafx.beans.property.{ObjectProperty, StringProperty}

// Case class representing a game result with properties for data binding
case class GameResult(
                       id: Int,
                       username: String,
                       difficulty: String,
                       datePlayed: Timestamp,
                       timeTaken: String,
                       movesTaken: Int) {

  // properties for data binding in ScalaFX
  val usernameProperty = StringProperty(username)
  val difficultyProperty = StringProperty(difficulty)
  val datePlayedProperty = ObjectProperty(datePlayed)
  val timeTakenProperty = StringProperty(timeTaken)
  val movesTakenProperty = ObjectProperty(movesTaken)
}
